<?php
/**  Silence is golden.
 */
