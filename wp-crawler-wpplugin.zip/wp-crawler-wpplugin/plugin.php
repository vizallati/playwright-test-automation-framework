<?php
/**
 * Website crawler as a WordPress plugin. Answer to the WP-Media developer test case.
 *
 * @package     wp-crawler
 * @author      Mathieu Lamiot
 * @copyright   2023 Mathieu Lamiot
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name: wp-crawler-wpplugin
 * Version:     0.0.1
 * Description: Website crawler as a WordPress plugin. Answer to the WP-Media developer test case.
 * Author:      Mathieu Lamiot
 * Author URI:  https://github.com/AgentAGadge
 */

namespace ROCKET_WP_CRAWLER;

define( 'ROCKET_CRWL_PLUGIN_FILENAME', __FILE__ ); // Filename of the plugin, including the file.

if ( ! defined( 'ABSPATH' ) ) { // If WordPress is not loaded.
	exit( 'WordPress not loaded. Can not load the plugin' );
}

// Load the dependencies installed through composer.
require_once __DIR__ . '/src/plugin.php';
require_once __DIR__ . '/vendor/autoload.php';

// Plugin initialization.
/**
 * Creates the plugin object on plugins_loaded hook
 *
 * @return void
 */
function wpc_crawler_plugin_init() {
	$wpc_crawler_plugin = new Rocket_Wpc_Plugin_Class();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\wpc_crawler_plugin_init' );

register_activation_hook( __FILE__, __NAMESPACE__ . '\Rocket_Wpc_Plugin_Class::wpc_activate' );
