<?php
/**
 *  Business logic and datamodel for the plan of the website including pages and links in between
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

define( 'ROCKET_CRWL_DB_PAGES_TABLENAME', 'wpc_pages' ); // Name of the table containing pages.
define( 'ROCKET_CRWL_DB_PAGELINKS_TABLENAME', 'wpc_pagelinks' ); // Name of the table containing links between pages.
define( 'ROCKET_CRWL_DB_PAGES_LIMIT_RESULTS', '100' ); // Name of the table containing links between pages.

define( 'ROCKET_CRWL_DB_CACHE_TTL', 3600 ); // Default time-to-live for cached objects.
define( 'ROCKET_CRWL_DB_CACHE_GROUP', '' ); // Default cache_group.
define( 'ROCKET_CRWL_DB_CACHE_PAGE_URL', 'wp_db_cache_key_page_url' ); // Cache key base for page getter by url.
define( 'ROCKET_CRWL_DB_CACHE_PAGES_ALL', 'wp_db_cache_key_all_pages' ); // Cache key for all pages getter.
define( 'ROCKET_CRWL_DB_CACHE_PAGELINK_ORIGINDEST_UUIDS', 'wp_db_cache_key_pagelink_origindest_uuids' ); // Cache key for all pages getter.
define( 'ROCKET_CRWL_DB_CACHE_PAGES_FROM_ORIGIN_UUID', 'wp_db_cache_key_pages_from_origin_uuid' ); // Cache key for pages from a origin uuid getter.
/**
 * Data access layer for the Webplan data model
 */
class Rocket_Wpc_Webplan_Data_Class {

	/**
	 * Constructor of the webplan data access layer.
	 * Creates tables if needed.
	 */
	public function __construct() {
	}

	// ---- DATABASE MANAGEMENT ----
	/**
	 * Initialization of the database by adding needed custom tables, typically on plugin activation.
	 *
	 * @return void
	 */
	public static function init_db() {
		self::init_pages_table();
		self::init_pagelinks_table();
	}

	/**
	 * Creation of the table pages and its datamodel, typically on plugin activation.
	 *
	 * @return void
	 */
	public static function init_pages_table() {
		global $wpdb;

		$table_name = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		uuid CHAR(36) NOT NULL,
		url VARCHAR(255) NOT NULL UNIQUE,
		PRIMARY KEY (uuid)
		) $charset_collate";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Creation of the table pagelinks and its datamodel, typically on plugin activation.
	 *
	 * @return void
	 */
	public static function init_pagelinks_table() {
		global $wpdb;
		$table_name      = $wpdb->prefix . ROCKET_CRWL_DB_PAGELINKS_TABLENAME;
		$page_table_name = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		uuid CHAR(36) NOT NULL,
		origin_page_uuid CHAR(36) NOT NULL,
		destination_page_uuid CHAR(36) NOT NULL,
		PRIMARY KEY (uuid),
		UNIQUE KEY unique_url_other_column (origin_page_uuid, destination_page_uuid),
		FOREIGN KEY (origin_page_uuid) REFERENCES $page_table_name (uuid),
		FOREIGN KEY (destination_page_uuid) REFERENCES $page_table_name (uuid)
		) $charset_collate";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Remove all custom tables from the database, typically on plugin deactivation.
	 *
	 * @return void
	 */
	public static function clean_db() {
		global $wpdb;

		$table_name = $wpdb->prefix . ROCKET_CRWL_DB_PAGELINKS_TABLENAME;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DROP TABLE IF EXISTS $table_name" ) );

		$table_name = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DROP TABLE IF EXISTS $table_name" ) );
	}

	// ---- CACHE TOOLS ----

	/**
	 * Builds the cache key to get a page by URL.
	 *
	 * @param string $page_url : URL of the page.
	 * @return string $cache_key : cache_key for the page getter by url.
	 */
	public function get_cache_key_page_url( $page_url ) {
		// Invalidate cache for getter by URL.
		$cache_key = ROCKET_CRWL_DB_CACHE_PAGE_URL . md5( $page_url );
		return( $cache_key );
	}

	/**
	 * Builds the cache key to get a pagelink by uuids of origin page and destination page.
	 *
	 * @param string $origin_uuid : uuid of the origin page of the pagelink.
	 * @param string $destination_uuid : uuid of the destination page of the pagelink.
	 * @return string $cache_key : cache_key for the getter of pagelink by origin and destination uuids.
	 */
	public function get_cache_key_pagelink_origindest_uuids( $origin_uuid, $destination_uuid ) {

		// Invalidate cache for getter by URL.
		$cache_key = ROCKET_CRWL_DB_CACHE_PAGELINK_ORIGINDEST_UUIDS . md5( $origin_uuid ) . md5( $destination_uuid );
		return ( $cache_key );
	}

	/**
	 * Builds the cache key to get all pages.
	 *
	 * @return string $cache_key : cache_key for the all pages getter.
	 */
	public function get_cache_key_all_pages() {
		// Invalidate cache for getter by URL.
		$cache_key = ROCKET_CRWL_DB_CACHE_PAGES_ALL;
		return( $cache_key );
	}

	/**
	 * Builds the cache key to get all pages.
	 *
	 * @param string $origin_uuid : uuid of the origin page of the pagelink.
	 * @return string $cache_key : cache_key for the all pages getter.
	 */
	public function get_cache_key_pages_from_origin_uuid( $origin_uuid ) {
		// Invalidate cache for getter by URL.
		$cache_key = ROCKET_CRWL_DB_CACHE_PAGES_FROM_ORIGIN_UUID . md5( $origin_uuid );
		return( $cache_key );
	}

	/**
	 * Deletes all cache objects related to the given pagelink, typically when it has been modified.
	 *
	 * @param string $origin_uuid : uuid of the origin page of the pagelink.
	 * @param string $destination_uuid : uuid of the destination page of the pagelink.
	 * @return void
	 */
	public function invalidate_cache_pagelink( $origin_uuid, $destination_uuid ) {

		// Invalidate cache for getter by URL.
		$cache_key = $this->get_cache_key_pagelink_origindest_uuids( $origin_uuid, $destination_uuid );
		wp_cache_delete( $cache_key );

		// Invalidate cache for getter by origin UUID.
		$cache_key = $this->get_cache_key_pages_from_origin_uuid( $origin_uuid );
		wp_cache_delete( $cache_key );
	}

	/**
	 * Deletes all cache objects related to the given page, typically when it has been modified.
	 *
	 * @param array $page : ARRAY_A of the new page object.
	 * @return void
	 */
	public function invalidate_cache_page( $page ) {

		// Invalidate cache for getter by URL.
		$cache_key = $this->get_cache_key_page_url( $page['url'] );
		wp_cache_delete( $cache_key );

		// Invalidate cache for all pages getter.
		$cache_key = $this->get_cache_key_all_pages();
		wp_cache_delete( $cache_key );
	}

	// ---- ---- ----

	/**
	 * Remove all entries of tables for the website plan that are not relevant anymore, typically during an update of the website plan.
	 * WARNING: Current behavior is to delete all entries from the tables.
	 *
	 * @return void
	 */
	public function delete_outdated_db() {
		global $wpdb;

		// Invalidate cache.
		wp_cache_flush();

		$table_name = $wpdb->prefix . ROCKET_CRWL_DB_PAGELINKS_TABLENAME;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM $table_name" ) );

		$table_name = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM $table_name" ) );
	}

	/**
	 * Looks for an entry in the pages table matching the provided URL and retrieves it, or null if it does not exist.
	 *
	 * @param string $page_url URL of the page to find.
	 * @return object Associate array key/value from the wpdb.wp_wpc_pages datamodel, or null if it does not exist.
	 */
	public function get_page_from_url( $page_url ) {

		$cache_key = $this->get_cache_key_page_url( $page_url );
		$result    = wp_cache_get( $cache_key );

		if ( false === $result ) {
			global $wpdb;
			$pages_table = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$result = $wpdb->get_row(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->prepare( "SELECT * FROM $pages_table WHERE url = %s", $page_url ),
				ARRAY_A
			);

			wp_cache_set( $cache_key, $result, ROCKET_CRWL_DB_CACHE_GROUP, ROCKET_CRWL_DB_CACHE_TTL );
		}
		return $result;
	}

	/**
	 * Try to insert a new page in the pages table, and returns the inserted entry.
	 *
	 * @param string $page_url URL of the page to add.
	 * @return object Associate array key/value from the wpdb.wp_wpc_pages datamodel or null if it was not inserted
	 */
	public function set_page_from_url( $page_url ) {
		global $wpdb;
		$pages_table = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;

		$uuid = wp_generate_uuid4();
		$page = array(
			'uuid' => $uuid,
			'url'  => $page_url,
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert( $pages_table, $page );

		// Invalidate cache.
		$this->invalidate_cache_page( $page );

		$result = $this->get_page_from_url( $page_url );

		return $result;
	}

	/**
	 * Insert the page in the pages table if it does not exist yet. Retrieves the corresponding entry.
	 *
	 * @param string $page_url URL of the page to try to add and retrieve from the DB.
	 * @return object Associate array key/value from the wpdb.wp_wpc_pages datamodel
	 */
	public function setget_page_from_url( $page_url ) {

		$result = $this->get_page_from_url( $page_url );

		if ( is_null( $result ) ) {
			$result = $this->set_page_from_url( $page_url );
		}

		return $result;
	}

	/**
	 * Retrieves all page's URLs available in the wp_wpc_pages table (up to a safeguard limit)
	 *
	 * @return array Array_N listing all registered urls where all values are associative arrays with key "url"
	 */
	public function get_all_pages_url() {

		$cache_key = $this->get_cache_key_all_pages();
		$result    = wp_cache_get( $cache_key );

		if ( false === $result ) {
			global $wpdb;
			$pages_table     = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;
			$safeguard_limit = ROCKET_CRWL_DB_PAGES_LIMIT_RESULTS;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$result = $wpdb->get_results(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->prepare( "SELECT url FROM $pages_table LIMIT %d", $safeguard_limit ),
				ARRAY_A
			);

			wp_cache_set( $cache_key, $result, ROCKET_CRWL_DB_CACHE_GROUP, ROCKET_CRWL_DB_CACHE_TTL );
		}

		return $result;
	}

	/**
	 * Looks for an entry in pagelinks table matching the origin page and destination page uuid from pages table and returns it, or null if it does not exist.
	 *
	 * @param string $origin_uuid UUID (FK from wp_wpc_pages) of the origin page of the link.
	 * @param string $destination_uuid UUID (FK from wp_wpc_pages) of the destination page of the link.
	 * @return object Associate array key/value from the wpdb.wp_wpc_pagelinks datamodel or null if it does not exist
	 */
	public function get_pagelink_from_uuid( $origin_uuid, $destination_uuid ) {

		$cache_key = $this->get_cache_key_pagelink_origindest_uuids( $origin_uuid, $destination_uuid );
		$result    = wp_cache_get( $cache_key );

		if ( false === $result ) {
			global $wpdb;
			$pagelinks_table = $wpdb->prefix . ROCKET_CRWL_DB_PAGELINKS_TABLENAME;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$result = $wpdb->get_row(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->prepare( "SELECT * FROM $pagelinks_table WHERE origin_page_uuid = %s and destination_page_uuid = %s", $origin_uuid, $destination_uuid ),
				ARRAY_A
			);
			wp_cache_set( $cache_key, $result, ROCKET_CRWL_DB_CACHE_GROUP, ROCKET_CRWL_DB_CACHE_TTL );
		}

		return $result;
	}

	/**
	 * Tries to insert a new pagelinks in wp_wpc_pagelinks from an origin_uuid and a destinaiton_uuid, and returns the inserted entry.
	 *
	 * @param string $origin_uuid UUID (FK from wp_wpc_pages) of the origin page of the link.
	 * @param string $destination_uuid UUID (FK from wp_wpc_pages) of the destination page of the link.
	 * @return object Associate array key/value from the wpdb.wp_wpc_pagelinks datamodel or null if it was not inserted
	 */
	public function set_pagelink_from_uuid( $origin_uuid, $destination_uuid ) {

		global $wpdb;
		$pagelinks_table = $wpdb->prefix . ROCKET_CRWL_DB_PAGELINKS_TABLENAME;

		$uuid = wp_generate_uuid4();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$pagelinks_table,
			array(
				'uuid'                  => $uuid,
				'origin_page_uuid'      => $origin_uuid,
				'destination_page_uuid' => $destination_uuid,
			)
		);

		// Invalidate cache.
		$this->invalidate_cache_pagelink( $origin_uuid, $destination_uuid );

		$result = $this->get_pagelink_from_uuid( $origin_uuid, $destination_uuid );

		return $result;
	}

	/**
	 * If it does not exist, insert a new pagelinks in wp_wpc_pagelinks from an origin_uuid and a destinaiton_uuid. Returns the related entry.
	 *
	 * @param string $origin_uuid UUID (FK from wp_wpc_pages) of the origin page of the link.
	 * @param string $destination_uuid UUID (FK from wp_wpc_pages) of the destination page of the link.
	 * @return object Associate array key/value from the wpdb.wp_wpc_pagelinks datamodel or null if it was not inserted and does not exist
	 */
	public function setget_pagelink_from_uuid( $origin_uuid, $destination_uuid ) {

		$result = $this->get_pagelink_from_uuid( $origin_uuid, $destination_uuid );

		if ( is_null( $result ) ) {
			$result = $this->set_pagelink_from_uuid( $origin_uuid, $destination_uuid );
		}

		return $result;
	}

	/**
	 * Looks for all pages accessible from a given origin_uuid and return them
	 *
	 * @param string $origin_uuid uuid of the origin page to filter on.
	 * @return array $result Associative array with all accessible pages
	 */
	public function get_pages_from_origin_uuid( $origin_uuid ) {

		$cache_key = $this->get_cache_key_pages_from_origin_uuid( $origin_uuid );
		$result    = wp_cache_get( $cache_key );

		if ( false === $result ) {
			global $wpdb;
			$pagelinks_table = $wpdb->prefix . ROCKET_CRWL_DB_PAGELINKS_TABLENAME;
			$pages_table     = $wpdb->prefix . ROCKET_CRWL_DB_PAGES_TABLENAME;

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$result = $wpdb->get_results(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->prepare( "SELECT p.* FROM $pages_table p JOIN $pagelinks_table pl on p.uuid = pl.destination_page_uuid  WHERE pl.origin_page_uuid = %s", $origin_uuid ),
				ARRAY_A
			);
			wp_cache_set( $cache_key, $result, ROCKET_CRWL_DB_CACHE_GROUP, ROCKET_CRWL_DB_CACHE_TTL );
		}

		return $result;
	}
}
