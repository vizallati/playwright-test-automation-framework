<?php
/**
 *  Manages the admin option page of the plugin
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

require_once __DIR__ . '/views/admin-tool-page.php';
require_once __DIR__ . '/controllers/webplan-controller.php';
require_once __DIR__ . '/cron/webplan-updater-cron.php';

/**
 * Main plugin class. It manages initialization, install, and activations.
 */
class Rocket_Wpc_Plugin_Class {
	/**
	 * Controller instance of the Crawler Cron.
	 *
	 * @var Rocket_Wpc_Crawler_Cron_Controller_Class
	 */
	private $crawler_cron;

	/**
	 * Manages plugin initialization
	 *
	 * @return void
	 */
	public function __construct() {

		// Register plugin lifecycle hooks.
		register_deactivation_hook( ROCKET_CRWL_PLUGIN_FILENAME, array( $this, 'wpc_deactivate' ) );
		// Admin Tool Page.
		$admin_page = new Rocket_Wpc_Admin_Tool_Page_Class();

		// Webplan Updater Cron.
		$this->crawler_cron = new Rocket_Wpc_Crawler_Cron_Controller_Class();

		// Webplan Controller.
		$webplan_controller = new Rocket_Wpc_Webplan_Controller_Class();
	}

	/**
	 * Handles plugin activation:
	 *  - Set up the database
	 *
	 * @return void
	 */
	public static function wpc_activate() {
		// Security checks.
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$plugin = isset( $_REQUEST['plugin'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['plugin'] ) ) : '';
		check_admin_referer( "activate-plugin_{$plugin}" );
		// Initialize DB.
		Rocket_Wpc_Webplan_Data_Class::init_db();
	}

	/**
	 * Handles plugin deactivation
	 *  - Flushes cache
	 *  - Unschedule cron jobs
	 *
	 * @return void
	 */
	public function wpc_deactivate() {
		// Security checks.
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$plugin = isset( $_REQUEST['plugin'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['plugin'] ) ) : '';
		check_admin_referer( "deactivate-plugin_{$plugin}" );

		Rocket_Wpc_Crawler_Cron_Controller_Class::deactivate();
		wp_cache_flush();
	}
}
