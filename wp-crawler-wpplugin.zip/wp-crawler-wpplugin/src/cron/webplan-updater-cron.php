<?php
/**
 *  Implements the crawler controller to access the crawler feature.
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

require_once dirname( __DIR__ ) . '/models/webplan-model.php';

// Constant definitions.
define( 'ROCKET_CRWL_CRON_HOOK_EXEC', 'wpc_cron_crawler_hook_exec' ); // CRON hook for the crawler cron.
define( 'ROCKET_CRWL_CRON_HOOK_SCHEDULE', 'wpc_cron_crawler_hook_schedule' ); // CRON hook for the crawler cron.
define( 'ROCKET_CRWL_CRON_TIMING_CRAWLER', 'hourly' ); // CRON hook for the crawler cron.
define( 'ROCKET_CRWL_CRON_CRAWL_GET_ACTION', 'wpc_wpcrawler_cron_crawl_get' ); // Action name to trigger a crawl on the AJAX endpoint.

/**
 * Controller class for the crawler cron. Handles scheduling, activation and execution of the crawler cron.
 */
class Rocket_Wpc_Crawler_Cron_Controller_Class {

	/**
	 * Constructor of the cron controller.
	 * Registers the custom hook to handle scheduled executions
	 */
	public function __construct() {
		// Register a custom hook for the crawler CRON.
		add_action( ROCKET_CRWL_CRON_HOOK_EXEC, array( $this, 'wpc_cron_crawler_exec' ) );
		add_action( ROCKET_CRWL_CRON_HOOK_SCHEDULE, array( $this, 'schedule' ) );

		add_action( 'wp_ajax_' . ROCKET_CRWL_CRON_CRAWL_GET_ACTION, array( $this, 'get_schedule_callback' ) );
	}

	/**
	 * Schedules the CRWL_CRON_HOOK_CRAWLER hourly if not already scheduled.
	 *
	 * @return void
	 */
	public function schedule() {
		wp_schedule_event( time() + 60, ROCKET_CRWL_CRON_TIMING_CRAWLER, ROCKET_CRWL_CRON_HOOK_EXEC );
	}

	/**
	 * Unschedules the CRWL_CRON_HOOK_CRAWLER, typically on plugin deactivation
	 *
	 * @return void
	 */
	public static function deactivate() {
		$timestamp = wp_next_scheduled( ROCKET_CRWL_CRON_HOOK_EXEC );
		wp_unschedule_event( $timestamp, ROCKET_CRWL_CRON_HOOK_EXEC );
	}

	/**
	 * Executes the CRWL_CRON_HOOK_CRAWLER by calling the crawler controller to perform a crawl and update DB
	 *
	 * @return void
	 */
	public function exec() {
		$webplan = new Rocket_Wpc_Webplan_Model_Class();
		$webplan->crawl_website();
		$webplan->save();
	}

	/**
	 * Check if the schedule of the crawl cron and returns the next timestamp
	 * Callback function for the action CRWL_CRON_CRAWL_GET_ACTION
	 *
	 * @return void
	 */
	public function get_schedule_callback() {
		$result = array();

		$next_timestamp = wp_next_scheduled( ROCKET_CRWL_CRON_HOOK_EXEC );
		if ( ! $next_timestamp ) {
			$result['is_scheduled'] = false;
		} else {
			$result['is_scheduled']   = true;
			$result['next_timestamp'] = $next_timestamp;
		}
		wp_send_json_success( $result );
	}
}
