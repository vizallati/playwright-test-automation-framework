<?php
/**
 *  Manages the admin option page of the plugin
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

// Constant definitions.
define( 'ROCKET_CRWL_ADMIN_TITLE', 'WP Crawler admn panel' ); // Name of the admin page.
define( 'ROCKET_CRWL_ADMIN_SLUG', 'wpcrawler_admin' ); // Control section title.
define( 'ROCKET_CRWL_ADMIN_WEBSTRUCT_TITLE', 'Website structure' ); // Overview section title.
define( 'ROCKET_CRWL_ADMIN_CRWLCTRL_TITLE', 'Crawl contrls' ); // Control section title.

// Includes and requires.
require_once dirname( __DIR__ ) . '/controllers/webplan-controller.php';
require_once dirname( __DIR__ ) . '/cron/webplan-updater-cron.php';

/**
 * Class for the Admin Tool Page of the plugin.
 */
class Rocket_Wpc_Admin_Tool_Page_Class {
	/**
	 * Array_A listing all the scripts to be enqueud for the page
	 * (key=>value) where key: object_name, value: object content [key=>value, key=>value, ...]
	 *
	 * @var array
	 */
	private $js_objects = array();

	/**
	 * Adds (or replace) a js object in $js_objects
	 *
	 * @param string $object_name name of the object.
	 * @param array  $object_content [key=>value, key=>value, ...].
	 * @return void
	 */
	public function add_js_object( $object_name, $object_content ) {
		$this->js_objects[ $object_name ] = $object_content;
	}

	/**
	 * Manages plugin initialization
	 *
	 * @return void
	 */
	public function __construct() {

		// Adds JS objects to be passed to the scripts.
		$this->add_js_object( 'crawler_request', array( 'action' => ROCKET_CRWL_ACTION ) );
		$this->add_js_object( 'update_pagesList', array( 'action' => ROCKET_GET_WEBSITE_PLAN_ACTION ) );
		$this->add_js_object( 'update_cron_crawler_overview', array( 'action' => ROCKET_CRWL_CRON_CRAWL_GET_ACTION ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_script' ) );
		add_action( 'admin_menu', array( $this, 'register_page' ) );
	}

	/**
	 *  Outputs the HTML of the admin option page of the plugin.
	 *  The page contains two main sections:
	 *      1) Website structure (overview of crawling results)
	 *      2) Crawl controls
	 *
	 * @return void
	 */
	public function generate_html() {
		// check user capabilities.
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<!-- HTML content of the page -->
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<!-- SECTION: Website structure -->
			<h2><?php echo esc_html( ROCKET_CRWL_ADMIN_WEBSTRUCT_TITLE ); ?></h2>
			<ul id="pages-list"></ul>
			<!-- TODO -->

			<!-- SECTION: Crawl Controls -->
			<h2><?php echo esc_html( ROCKET_CRWL_ADMIN_CRWLCTRL_TITLE ); ?></h2>
			<button id="wpcrawler-crawl-button" class="button button-primary">Crawl Website</button>
			<p id="wpcrawler-cron-crawl-status"></p>
		</div>
		<?php
	}


	/**
	 * Register page to WordPress admin
	 *
	 * @return void
	 */
	public function register_page() {
		add_submenu_page(
			'tools.php',
			ROCKET_CRWL_ADMIN_TITLE,
			ROCKET_CRWL_ADMIN_TITLE,
			'manage_options',
			ROCKET_CRWL_ADMIN_SLUG,
			array( $this,'generate_html' )
		);
	}

	/**
	 * Enqueues the website-plan-script when loading the WP Crawler admin page.
	 *
	 * @param string $hook slug of the page being loaded.
	 * @return void
	 */
	public function enqueue_script( $hook ) {
		if ( 'tools_page_' . ROCKET_CRWL_ADMIN_SLUG === $hook ) { // Only enqueues the script for the WP Crawler admin page.
			wp_enqueue_script( 'website-plan-script', plugin_dir_url( __FILE__ ) . 'js/website-plan-script.js', array( 'jquery' ), '1.0', true );

			foreach ( $this->js_objects as  $object_name => $object_content ) {
				wp_localize_script(
					'website-plan-script',
					$object_name,
					$object_content
				);
			}
		}
	}
}

