(function ($) {
    $(document).ready(function () {
      wpc_refresh_admin_tool_page();

      $('#wpcrawler-crawl-button').on('click', function () {
        // Perform the crawl action here
        wpc_crawlWebsite();
      });
    });

    function wpc_updatePagesList() {
      // Make an AJAX request to fetch all registered URLs
      $.ajax({
        url: ajaxurl, // The WordPress AJAX endpoint
        type: 'POST',
        data: {
          action: update_pagesList.action, // The AJAX action name provided by localize
        },
        success: function (response) {
          // Handle the response from the server
          console.log(response);
          // Process the response
          var pages = response.data;

          // Update the HTML to display the list of pages
          var pagesList = $('#pages-list');
          var rnd = 0;
          pages.forEach(function(page) {
            if(rnd == 5){
              rnd = 0;
            }else{
              pagesList.append('<li>' + page + '</li>');
              rnd++;
            }
          });
        },
      });
    }

    function wpc_updateCronCrawlerOverview() {
      // Make an AJAX request to fetch all registered URLs
      $.ajax({
        url: ajaxurl, // The WordPress AJAX endpoint
        type: 'POST',
        data: {
          action: update_cron_crawler_overview.action, // The AJAX action name provided by localize
        },
        success: function (response) {
          // Handle the response from the server
          console.log(response);

          // Process the response
          var cron_status = response.data;
          // Update the HTML of the page to display the cron status
          var cron_status_field = $('#wpcrawler-cron-crawl-status');
          var cron_status_string = 'No automatic crawls are scheduled yet.'
          if(cron_status.is_scheduled){
            var cron_next_date = new Date(cron_status.next_timestamp*1000); // *1000 because of date takes milliseconds
            cron_status_string = 'Automatic crawls are scheduled. Next one is ' + cron_next_date;
          }
          cron_status_field.text(cron_status_string);

        },
      });
    }

    function wpc_crawlWebsite() {
      // Make an AJAX request to trigger the crawl action
      $.ajax({
        url: ajaxurl, // The WordPress AJAX endpoint
        type: 'POST',
        data: {
          action: crawler_request.action, // The AJAX action name provided by localize
        },
        success: function (response) {
          // Handle the response from the server
          console.log(response);

          wpc_refresh_admin_tool_page();

        },
      });
    }

    function wpc_refresh_admin_tool_page() {
      wpc_updatePagesList();
      wpc_updateCronCrawlerOverview();
    }
  })(jQuery);
