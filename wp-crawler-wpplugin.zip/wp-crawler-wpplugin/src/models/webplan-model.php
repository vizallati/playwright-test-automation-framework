<?php
/**
 *  Implements the crawler logic
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

use DOMDocument;
use DOMXPath;
use WP_Http;

define( 'ROCKET_CRWL_LOOP_LIMIT', 5 ); // Depth safeguard for the recursive crawl algorithm.

// Includes and requires.
require_once dirname( __DIR__ ) . '/support/url-utils.php';
require_once dirname( __DIR__ ) . '/data/webplan-data.php';

class Rocket_Wpc_Webplan_Model_Class {

	/**
	 * Homepage of the website. Root of crawls and webplans. By default, homepage of the WordPress website.
	 *
	 * @var string
	 */
	private $homepage_url;

	/**
	 * List all pages found in the website and its links.
	 * Associative array: key -> url of the origin page ; value -> List of urls of destination pages.
	 *
	 * @var array
	 */
	private $crawled_pages;

	/**
	 * Data access layer for the webplan datamodel
	 *
	 * @var Rocket_Wpc_Webplan_Data_Class
	 */
	private $db_webplan;

	/**
	 * Constructor of the webplan data access layer.
	 * Creates tables if needed.
	 */
	public function __construct() {
		$this->homepage_url  = get_home_url(); // Get the URL of the homepage.
		$this->crawled_pages = array();
		$this->db_webplan    = new Rocket_Wpc_Webplan_Data_Class();
	}

	/**
	 * Getter for $homepage_url.
	 *
	 * @return string $this->homepage_url;
	 */
	public function get_homepage_url() {
		return $this->homepage_url;
	}

	/**
	 * Getter for $crawled_pages.
	 * Returns the webplan, containing pages and their links.
	 *
	 * @return string $this->crawled_pages;
	 */
	public function get_webplan() {
		return $this->crawled_pages;
	}

	/**
	 * Getter for a list of all pages, without link information.
	 *
	 * @return array $this->crawled_pages;
	 */
	public function get_pagelist() {
		return array_keys( $this->crawled_pages );
	}


	/**
	 * Implements the recursive crawl logic from the homepage.
	 * Two array are used:
	 *  - discovered_pages contains a list of all internal pages that appeared at least once during a page crawl.
	 *  - crawled_pages contains an associated array: key -> url of the origin page ; value -> List of urls of destination pages.
	 * As long as there are less elements in crawled_pages than discovered_pages, there are still internal pages to crawl.
	 *
	 * @return array see above (crawled_pages)
	 */
	public function crawl_website() {

		$discovered_pages    = array(); // Array of discovered internal pages.
		$this->crawled_pages = array(); // Array of crawled pages (key) and all their links (values).

		array_push( $discovered_pages, $this->homepage_url );

		$depth_counter       = 0;
		$nb_discovered_pages = count( $discovered_pages );
		$nb_crawled_pages    = count( $this->crawled_pages );
		while ( $nb_discovered_pages > $nb_crawled_pages && $depth_counter < ROCKET_CRWL_LOOP_LIMIT ) {
			++$depth_counter;

			// There are discovered pages to crawl.
			foreach ( $discovered_pages as $page_to_crawl_url ) {
				if ( ! array_key_exists( $page_to_crawl_url, $this->crawled_pages ) ) {
					// This page is discovered but not crawled yet.
					$accessible_pages                          = $this->crawl_page( $page_to_crawl_url ); // Crawl it.
					$this->crawled_pages[ $page_to_crawl_url ] = $accessible_pages; // Store the results.

					// Check for new discovered pages.
					foreach ( $accessible_pages as $accessible_page ) {
						if ( ! in_array( $accessible_page, $discovered_pages, true ) // Page is undiscovered yet.
							&& ( is_page_internal( $accessible_page ) ) // Page is internal.
						) {
							array_push( $discovered_pages, $accessible_page );
						}
					}
				}
			}

			$nb_discovered_pages = count( $discovered_pages );
			$nb_crawled_pages    = count( $this->crawled_pages );
		}
		return $this->get_webplan();
	}

	/**
	 * Retrieves all the URLs in the HTML from a given URL
	 *
	 * @param string $page_url : URL of the page to parse.
	 * @return array All valid URLs found in anchor tags.
	 */
	private function crawl_page( $page_url ) {
		$pages    = array();
		$response = wp_remote_get( $page_url ); // Retrieve the HTML of the page.
		if ( is_wp_error( $response ) ) {
			// Error handling if the request fails.
			return $pages;
		}

		if ( wp_remote_retrieve_response_code( $response ) === WP_Http::OK ) {
			$html = wp_remote_retrieve_body( $response ); // Get the HTML content.

			// Use DOMDocument and DOMXPath to parse the HTML.
			$dom = new DOMDocument();
			libxml_use_internal_errors( true ); // Disable HTML parsing errors.
			$dom->loadHTML( $html );
			libxml_clear_errors();

			$xpath = new DOMXPath( $dom );

			// Find all anchor tags within the homepage HTML.
			$anchor_nodes = $xpath->query( '//a' );

			foreach ( $anchor_nodes as $anchor_node ) {
				$href = $anchor_node->getAttribute( 'href' ); // Get the href attribute value.

				// Check if the href is a valid URL and not an anchor.
				if ( is_valid_url_from_href( $href ) ) {
					// Add the page URL to the array.
					$pages[] = $href;
				}
			}
		}
		return $pages;
	}

	/** Updates the webplan data from the object's webplan (an associate array).
	 * Outdated entries in the DB are deleted. Then, we make sure all pages and links are present or added in the DB.
	 *
	 * @return void
	 */
	public function save() {
		$this->db_webplan->delete_outdated_db();

		foreach ( $this->crawled_pages as $origin_page_url => $destination_pages_url ) {
			$origin_page = $this->db_webplan->setget_page_from_url( $origin_page_url );
			foreach ( $destination_pages_url as $destination_page_url ) {
				$destination_page = $this->db_webplan->setget_page_from_url( $destination_page_url );
				$this->db_webplan->setget_pagelink_from_uuid( $origin_page['uuid'], $destination_page['uuid'] );
			}
		}
	}

	/** Loads the webplan from the database to the object associate array.
	 * Performs a DB crawl from the homepage.
	 *
	 * @return void
	 */
	public function load() {
		$discovered_pages    = array(); // Array of discovered internal pages.
		$this->crawled_pages = array(); // Array of crawled pages (key) and all their links (values).

		array_push( $discovered_pages, $this->homepage_url );

		$depth_counter       = 0;
		$nb_discovered_pages = count( $discovered_pages );
		$nb_crawled_pages    = count( $this->crawled_pages );
		while ( $nb_discovered_pages > $nb_crawled_pages && $depth_counter < ROCKET_CRWL_LOOP_LIMIT ) {
			++$depth_counter;

			// There are discovered pages to crawl.
			foreach ( $discovered_pages as $page_to_crawl_url ) {
				if ( ! array_key_exists( $page_to_crawl_url, array_keys( $this->crawled_pages ) ) ) {
					// This page is discovered but links not added yet.
					$page_to_crawl                                = $this->db_webplan->get_page_from_url( $page_to_crawl_url );
					$accessible_pages                             = $this->db_webplan->get_pages_from_origin_uuid( $page_to_crawl['uuid'] );
					$this->crawled_pages[ $page_to_crawl['url'] ] = array(); // Prepare to store the results.

					foreach ( $accessible_pages as $accessible_page ) {

						array_push( $this->crawled_pages[ $page_to_crawl['url'] ], $accessible_page['url'] ); // Store the results.

						// Check for new discovered pages.
						if ( ! in_array( $accessible_page['url'], $discovered_pages, true ) // Page is undiscovered yet.
							&& ( is_page_internal( $accessible_page['url'] ) ) // Page is internal.
						) {
							array_push( $discovered_pages, $accessible_page['url'] );
						}
					}
				}
			}
			$nb_discovered_pages = count( $discovered_pages );
			$nb_crawled_pages    = count( $this->crawled_pages );
		}
	}
}
