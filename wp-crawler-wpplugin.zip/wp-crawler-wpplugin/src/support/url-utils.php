<?php
/**
 *  Utility functions to handle URL
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

/**
 * Checks if the URL is internal to the website.
 *
 * @param string $page_url URL of the page to test.
 * @return boolean true is the page is internal to the website
 */
function is_page_internal( $page_url ) {
	$is_internal = false;

	$is_internal |= ( strpos( $page_url, 'http' ) !== 0 );          // Relative reference URL.
	$is_internal |= ( strpos( $page_url, get_home_url() ) === 0 );  // Starts with homepage URL.

	return $is_internal;
}

/**
 * Checks if the href anchor contains a valid URL
 *
 * @param string $href href anchor value to test.
 * @return boolean true is the href value is a valid URL
 */
function is_valid_url_from_href( $href ) {
	$is_valid = true;

	if ( ! filter_var( $href, FILTER_VALIDATE_URL ) ) {
		$is_valid = false;
	}
	if ( strpos( $href, '#' ) === 0 ) {
		$is_valid = false;
	}
	if ( strpos( $href, 'mailto' ) === 0 ) {
		$is_valid = false;
	}
	return $is_valid;
}
