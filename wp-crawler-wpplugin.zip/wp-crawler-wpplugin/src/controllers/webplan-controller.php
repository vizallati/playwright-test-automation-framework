<?php
/**
 *  Implements the crawler controller to access the crawler feature.
 *
 * @package     wp-crawler
 * @since       0.0.1
 * @author      Mathieu Lamiot
 * @license     GPL-2.0-or-later
 */

namespace ROCKET_WP_CRAWLER;

// Constant definitions.
define( 'ROCKET_CRWL_ACTION', 'wpc_wpcrawler_crawl_website' ); // Action name to trigger a crawl on the AJAX endpoint.
define( 'ROCKET_GET_WEBSITE_PLAN_ACTION', 'wpc_wpcrawler_get_website_plan' ); // Action name to trigger a crawl on the AJAX endpoint.

// Includes and requires.
require_once dirname( __DIR__ ) . '/models/webplan-model.php';
require_once dirname( __DIR__ ) . '/cron/webplan-updater-cron.php';


class Rocket_Wpc_Webplan_Controller_Class {

	/**
	 * Manages controller initialization and hooks registration.
	 *
	 * @return void
	 */
	public function __construct() {

		add_action( 'wp_ajax_' . ROCKET_CRWL_ACTION, array( $this, 'crawl_website_and_update_plan_callback' ) );
		add_action( 'wp_ajax_' . ROCKET_GET_WEBSITE_PLAN_ACTION, array( $this, 'get_website_pagelist_callback' ) );
	}

	/**
	 * Callback function for the action CRWL_ACTION to trigger a crawl of the website, update the database and return the obtained pages.
	 * The call is not accessible to not authentified users.
	 *
	 * @return void
	 */
	public function crawl_website_and_update_plan_callback() {
		$this->crawl_website_and_update_plan();
		wp_send_json_success();
	}

	/**
	 * Callback function of the GET_WEBSITE_PLAN_ACTION action to get a list of registered pages.
	 * Sends back a a JSON encoded ARRAY_N, where each element contains a "url" key and the url as value.
	 *
	 * @return void
	 */
	public function get_website_pagelist_callback() {

		$webplan = new Rocket_Wpc_Webplan_Model_Class();
		$webplan->load();
		$result = $webplan->get_pagelist();
		wp_send_json_success( $result );
	}

	/**
	 * Performs a compelte crawl of the website, then stores the pages and their links in the database.
	 * A cron job is scheduled to repeat the action every hour.
	 * Pages and links are returned as an associative array.
	 *
	 * @return array Associative array: key -> url of the origin page ; value -> List of urls of destination pages.
	 */
	public function crawl_website_and_update_plan() {

		$webplan = new Rocket_Wpc_Webplan_Model_Class();
		$webplan->crawl_website();
		$webplan->save();

		// Ensure the cron job is scheduled.
		do_action( ROCKET_CRWL_CRON_HOOK_SCHEDULE );

		// Return the response.
		return $webplan;
	}
}
